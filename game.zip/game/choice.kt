fun Choice(choice: String, hpDragon: Int, damagePlayer: Int, mercy: Int): Pair<Int, Int> {
    var HpDragon = 0
    var Mercy = mercy
    when (choice) {
        "д" -> {
            HpDragon = (hpDragon - damagePlayer).coerceAtLeast(0)
            println("вы ударили дракона. хп дракона: $HpDragon")
            Mercy = 4
        }

        "н" -> {
            HpDragon = (hpDragon).coerceAtLeast(0)
            println("вы не ударили дракона")
            Mercy += 1
        }

        else -> {
            println("ошибка")
            HpDragon = (hpDragon).coerceAtLeast(0)
        }

    }
    return Pair(HpDragon, Mercy)
}